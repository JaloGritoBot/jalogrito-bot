import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

user_scores = {}

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        InlineKeyboardButton("🔥 Играть!", callback_data="play"),
        InlineKeyboardButton("📣 Подписаться на канал", url="https://t.me/your_channel_here")
    )
    await message.answer(
        "👋 Добро пожаловать в JaloGritoCoin!

"
        "Жми кнопку, зарабатывай монеты и становись легендой 💰🔥",
        reply_markup=keyboard
    )

@dp.callback_query_handler(lambda c: c.data == "play")
async def handle_play(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    user_scores[user_id] = user_scores.get(user_id, 0) + 1

    keyboard = InlineKeyboardMarkup().add(
        InlineKeyboardButton("🔥 Ещё!", callback_data="play")
    )

    await bot.edit_message_text(
        chat_id=callback_query.message.chat.id,
        message_id=callback_query.message.message_id,
        text=f"💸 Твои монеты: {user_scores[user_id]}",
        reply_markup=keyboard
    )
    await bot.answer_callback_query(callback_query.id)

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
